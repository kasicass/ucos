#define ILOG2_C
#include "ilog2.h"
